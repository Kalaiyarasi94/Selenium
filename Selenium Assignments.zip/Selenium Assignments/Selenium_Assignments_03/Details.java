package Selenium_Assignments_03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Details extends MakeTrip  {
	@Test
	void getData()
	
	{
		WebDriver driver=this.login();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[1]/ul/li[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"fromCity\"]")).click();
		driver.findElement(By.xpath("//*[@id='react-autowhatever-1-section-0-item-1']/div")).click();
		driver.findElement(By.xpath("//*[@id='react-autowhatever-1-section-0-item-0']/div/div[1]/p[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[3]/div[6]/div/p")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/p/a")).click();

	}
}