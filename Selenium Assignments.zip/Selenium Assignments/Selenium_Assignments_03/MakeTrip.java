package Selenium_Assignments_03;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MakeTrip {

	WebDriver login()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.makemytrip.com/");
		return driver;
	}
}
