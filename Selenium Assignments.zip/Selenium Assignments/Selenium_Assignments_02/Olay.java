package Selenium_Assignments_02;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Olay {
	
	WebDriver login()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.olay.co.uk/en-gb");
		return driver;
	}
	WebDriver loginSpain()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.olay.es/es-es");
		return driver;
	}
	
		WebDriver loginGerm()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.olaz.de/de-de");
		return driver;
	}

}
