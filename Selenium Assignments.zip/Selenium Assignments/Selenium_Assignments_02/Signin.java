package Selenium_Assignments_02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Signin extends Olay {
//	@Test(priority=0)
	void Uk() throws InterruptedException
	{
		WebDriver driver=this.login();
		driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[emails][0][address]\"]")).sendKeys("start1@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][password]\"]")).sendKeys("Good@123");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][confirm]\"]")).sendKeys("Good@123");
		Select ss=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][day]\"]")));
		ss.selectByValue("28");
		Select ss1=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][month]\"]")));
		ss1.selectByVisibleText("10");
		Select ss2=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][year]\"]")));
		ss2.selectByValue("1994");
		Thread.sleep(2000);
		WebElement submit=driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_submit\"]"));
		submit.click();
	}
//	@Test(priority=1)
	void chin() throws IOException, ParseException, InterruptedException
	{
		JSONParser sp=new JSONParser();
		FileReader reader=new FileReader("C:/Users/Kalaiarasi/Desktop/data.json");
		Object obj=sp.parse(reader);
		JSONArray us=(JSONArray) obj;
		for(int i=0;i<us.size();i++)
		{
			JSONObject users=(JSONObject) us.get(i);
			JSONObject user=(JSONObject) users.get("user");
			String username=(String) user.get("username");
			String passwd=(String) user.get("passwrd");
			String conpass=(String) user.get("conpswd");
			String first=(String) user.get("first");
			String last=(String) user.get("last");
			String id=(String) user.get("id");
	
		WebDriver driver=this.loginSpain();
		
		driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_imgfemale\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[firstname]\"]")).sendKeys(first);
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[lastname]\"]")).sendKeys(last);
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[emails][0][address]\"]")).sendKeys(id);
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[emails][0][address]\"]")).sendKeys(username);
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][password]\"]")).sendKeys(passwd);
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][confirm]\"]")).sendKeys(conpass);
		Select ss=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][day]\"]")));
		ss.selectByValue("28");
		Select ss1=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][month]\"]")));
		ss1.selectByVisibleText("10");
		Select ss2=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][year]\"]")));
		ss2.selectByValue("1994");
		Thread.sleep(2000);
		WebElement submit=driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_submit\"]"));
		submit.click();
	
	}}
//		@Test(priority=2)
		void germ() throws IOException, InterruptedException
		{

	String path=("C:/Users/Kalaiarasi/Desktop/Data.xlsx");
	File file=new File(path);
	FileInputStream fos=new FileInputStream(file);
	XSSFWorkbook work=new XSSFWorkbook(fos);;
	XSSFSheet sheet=work.getSheetAt(0);
 
	String first=sheet.getRow(0).getCell(0).getStringCellValue();
	String last=sheet.getRow(1).getCell(0).getStringCellValue();
	String mail=sheet.getRow(2).getCell(0).getStringCellValue();
	String pass=sheet.getRow(3).getCell(0).getStringCellValue();
	String conpass=sheet.getRow(4).getCell(0).getStringCellValue();
	String num=sheet.getRow(5).getCell(0).getStringCellValue();
	String post=sheet.getRow(6).getCell(0).getStringCellValue();
	String ort=sheet.getRow(7).getCell(0).getStringCellValue();
	WebDriver driver=this.loginGerm();
	
	driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[2]")).click();
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_imgfemale\"]")).click();
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[firstname]\"]")).sendKeys(first);
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[lastname]\"]")).sendKeys(last);
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[emails][0][address]\"]")).sendKeys(mail);
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][password]\"]")).sendKeys(pass);
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][confirm]\"]")).sendKeys(conpass);
	Select ss=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][day]\"]")));
	ss.selectByValue("28");
	Select ss1=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][month]\"]")));
	ss1.selectByVisibleText("10");
	Select ss2=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][year]\"]")));
	ss2.selectByValue("1994");
	Select land=new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][country]\"]")));
	land.selectByIndex(0);
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][line1]\"]")).sendKeys(num);
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[addresses][0][postalarea]\"]")).sendKeys(post);
	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][city]\"]")).sendKeys(ort);
	
	}
//@Test
//void invalid() throws InterruptedException {
//	WebDriver driver=this.login();
//	driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[1]")).click();
//	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_username\"]")).sendKeys("start1@gmail.com");
//	driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_password\"]")).sendKeys("password");
//	Thread.sleep(2000);
//	driver.findElement(By.id("phdesktopbody_0_SIGN IN")).click();
//}
}
