package Selenium_Assignments_01;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class DatePicker extends DemoQALogin {
	@Test
	void retriveDate()
	{
		WebDriver driver = this.loginDate();
		driver.findElement(By.xpath("//*[@id=\"datepicker\"]")).sendKeys("10/28/1994");
		
	}

}
