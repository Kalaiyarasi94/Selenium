package Selenium_Assignments_01;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Droppable extends DemoQALogin {
@Test
void getDrag()
{
	WebDriver driver = this.loginDrop();
	Actions a=new Actions(driver);
	WebElement source = driver.findElement(By.xpath("//*[@id=\"draggable\"]/p"));
	WebElement to = driver.findElement(By.xpath("//*[@id=\"droppable\"]"));
	a.dragAndDrop(source, to).perform();
	System.out.println(to.getText());
}
}
