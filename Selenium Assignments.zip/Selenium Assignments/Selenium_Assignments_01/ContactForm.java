package Selenium_Assignments_01;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.safari.SafariDriver.WindowType;
import org.testng.annotations.Test;

public class ContactForm extends DemoQALogin {
	WebDriver driver=this.loginContact();
@Test(priority=1)
void firstName()
{
//	WebDriver driver=this.loginContact();
	driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[1]")).sendKeys("Kalai");
}
@Test(priority=2)
void LastName()
{
//	WebDriver driver=this.loginContact();
	driver.findElement(By.xpath("//*[@id=\"lname\"]")).sendKeys("Selva");
}
@Test(priority=3)
void Country()
{
//	WebDriver driver=this.loginContact();
	driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[3]")).sendKeys("India");
}
@Test(priority=4)
void Subject()
{
//	WebDriver driver=this.loginContact();
	driver.findElement(By.xpath("//*[@id=\"subject\"]")).sendKeys("Enter the subject");
}
@Test(priority=5)
void Submit()
{
//	WebDriver driver=this.loginContact();
	driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[4]")).click();;
}

@Test(priority=6)
void googleIs() {
	ArrayList<String> tab=new ArrayList<String>(driver.getWindowHandles());
	driver.switchTo().window(tab.get(0));
	driver.get("https:/demoqa.com/html-contact-form/");
WebElement google = driver.findElement(By.partialLinkText("Link"));
System.out.println(google.getText());
}
@Test(priority=7)
void googleIsHere() {
	ArrayList<String> tab=new ArrayList<String>(driver.getWindowHandles());
	driver.switchTo().window(tab.get(1));
	driver.get("https:/demoqa.com/html-contact-form/");
WebElement googleIs = driver.findElement(By.partialLinkText("is here"));
System.out.println(googleIs.getText());
}
}

