package Selenium_Assignments_01;

import java.awt.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class ControlGroup extends DemoQALogin {
	@Test
	void control()
	{
	WebDriver driver=this.loginControlGroup();
	driver.findElement(By.xpath("//*[@id=\"ui-id-8-button\"]/span[2]")); 	
	WebElement stand = driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/fieldset[2]/div/label[2]"));
	stand.click();
	WebElement check = driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/fieldset[2]/div/label[3]/span[1]"));
	check.click();
	WebElement carcount = driver.findElement(By.xpath("//*[@id=\"vertical-spinner\"]"));
	carcount.sendKeys("2");
	driver.findElement(By.xpath("//*[@id=\"book\"]")).click();
}
}
