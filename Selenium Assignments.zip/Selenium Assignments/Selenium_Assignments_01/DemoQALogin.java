package Selenium_Assignments_01;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DemoQALogin {
	@Test
	WebDriver login()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
	WebDriver driver=new ChromeDriver();
	driver.get("https:/demoqa.com/selectable/");
	return driver;

	}
	@Test
	WebDriver loginContact()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https:/demoqa.com/html-contact-form/");
		return driver;
	}
	@Test
	WebDriver loginDrop()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https:/demoqa.com/droppable/");
		return driver;
	}
	@Test
	WebDriver loginDate()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https:/demoqa.com/datepicker/");
		return driver;
}
	@Test
	WebDriver loginSelectMenu()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https:/demoqa.com/selectmenu/");
		return driver;
	}
	@Test
	WebDriver loginControlGroup()
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/Kalaiarasi/Desktop/chromedriver.exe" );
		WebDriver driver=new ChromeDriver();
		driver.get("https:/demoqa.com/controlgroup/");
		return driver;
		
	}
}
