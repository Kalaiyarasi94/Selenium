package Selenium_Assignments_01;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class SelectMenu extends DemoQALogin{
	@Test
	void menuSelection() throws InterruptedException
	{
		WebDriver driver = this.loginSelectMenu();
//		driver.manage().timeouts().implicitlyWait(2000,TimeUnit.SECONDS);
		Thread.sleep(2000);
		WebElement speed = driver.findElement(By.xpath("//*[@id=\"speed\"]"));
		Select speed1=new Select(speed);         
				
		speed1.selectByIndex(1);
//		Select file=new Select(driver.findElement(By.xpath("//*[@id=\"files-button\"]/span[2]")));
//		file.selectByIndex(2);
//		Select number=new Select(driver.findElement(By.xpath("//*[@id=\"number-button\"]/span[2]")));
//		number.selectByVisibleText("2");
//		Select title=new Select(driver.findElement(By.xpath("//*[@id=\"salutation-button\"]/span[2]")));
//		title.selectByIndex(4);
	}

}
